const FancyBorder = ({ children }) => {
  return <div className="fancy">{children}</div>;
};

export default FancyBorder;
