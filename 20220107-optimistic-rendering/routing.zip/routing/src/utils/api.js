import axios from 'axios';

const spaceApi = axios.create({
  baseURL: 'https://space-facts.herokuapp.com/api',
});

export const getPlanets = () => {
  return spaceApi.get('/planets').then((res) => {
    return res.data.planets;
  });
};
