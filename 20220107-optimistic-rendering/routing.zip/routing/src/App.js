import './App.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Home from './componets/Home';
import Nav from './componets/Nav';
import PlanetsList from './componets/PlanetsList';
import SinglePlanet from './componets/SinglePlanet';

function App() {
  return (
    <BrowserRouter>
      <div className="App">
        <Nav />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/planets" element={<PlanetsList />} />
          <Route path="/planets/:planet_id" element={<SinglePlanet />} />
        </Routes>
      </div>
    </BrowserRouter>
  );
}

export default App;
