import React from 'react';
import { Link } from 'react-router-dom';

const Nav = () => {
  return (
    <nav className="Nav">
      <Link to="/">
        <p className="Nav__link">Home</p>
      </Link>
      <Link to="/planets">
        <p className="Nav__link">Planets</p>
      </Link>
    </nav>
  );
};

export default Nav;
