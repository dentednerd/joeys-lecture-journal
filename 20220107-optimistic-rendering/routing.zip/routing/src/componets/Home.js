import React from 'react';

const Home = () => {
  return (
    <section>
      <h1>Welcome!</h1>
    </section>
  );
};

export default Home;
