import React from 'react';
import { useParams } from 'react-router-dom';

const SinglePlanet = () => {
  const { planet_id } = useParams(); //kjhsak`dh
  //useEffect, make our function call to api
  //pass planet_id to function and make the axios request
  //use returned data and set into state
  //render on page info in state

  return <h1>Single Planet!</h1>;
};

export default SinglePlanet;
