import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { getPlanets } from '../utils/api';

const PlanetsList = () => {
  const [planets, setPlanets] = useState([]);

  useEffect(() => {
    getPlanets().then((planetsFromApi) => {
      setPlanets(planetsFromApi);
    });
  }, []);

  return (
    <main>
      <h1>Planets</h1>
      <ul>
        {planets.map((planet) => {
          return (
            <li key={planet.planet_id}>
              <Link to={`/planets/${planet.planet_id}`}>
                <h2>{planet.planet_name}</h2>
              </Link>
            </li>
          );
        })}
      </ul>
    </main>
  );
};

export default PlanetsList;
